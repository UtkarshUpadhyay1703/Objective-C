//
//  Person.h
//  File Operations
//
//  Created by admin on 5/12/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Person : NSObject
@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSNumber *age;
@end

NS_ASSUME_NONNULL_END
