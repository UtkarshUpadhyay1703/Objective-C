//
//  ViewController.m
//  DN impl Server
//
//  Created by admin on 6/5/23.
//

#import "ViewController.h"
#import "ChatController.h"

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths firstObject];
    self.filePath = [documentsDirectory stringByAppendingPathComponent:@"ChatAppTeacher.plist"];
    self.teacher = [NSMutableDictionary dictionaryWithContentsOfFile:self.filePath];
    if (![self.teacher valueForKey:@"teacher"]) {
        self.teacher = [NSMutableDictionary dictionary];
        NSLog(@"No Teacher");
    }else{
        ChatController *chatController = [[ChatController alloc] initWithUserName:[_teacher valueForKey:@"teacher"]];
        NSLog(@"Teacher name = %@",[_teacher valueForKey:@"teacher"]);
        [self presentViewControllerAsModalWindow:chatController];
    }
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}


- (IBAction)loginButtonClicked:(id)sender {
    NSString *user = self.username.stringValue;
    if(user.length>0){
        [_teacher setValue:user forKey:@"teacher"];
        if([_teacher writeToFile:self.filePath atomically:YES]){
            NSLog(@"Teacher useername written properly");
            ChatController *chatController = [[ChatController alloc] initWithUserName:user];
            [self presentViewControllerAsModalWindow:chatController];
        }
        else NSLog(@"Failed to write teacher useername inside file");
    }
}
@end
