//
//  AppDelegate.h
//  DN impl Client
//
//  Created by admin on 6/5/23.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

