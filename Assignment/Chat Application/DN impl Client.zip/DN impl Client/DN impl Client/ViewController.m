//
//  ViewController.m
//  DN impl Client
//
//  Created by admin on 6/5/23.
//

#import "ViewController.h"
#import "ChatController.h"
@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths firstObject];
    self.filePath = [documentsDirectory stringByAppendingPathComponent:@"ChatAppStudent.plist"];
    self.student = [NSMutableDictionary dictionaryWithContentsOfFile:self.filePath];
    if (![self.student valueForKey:@"student"]) {
        self.student = [NSMutableDictionary dictionary];
        NSLog(@"No Student");
    }else{
        ChatController *chatController = [[ChatController alloc] initWithUserName:[_student valueForKey:@"student"]];
        NSLog(@"Student name = %@",[_student valueForKey:@"student"]);
        [self presentViewControllerAsModalWindow:chatController];
    }
    
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}


- (IBAction)login:(id)sender {
    NSString *user = self.username.stringValue;
    if(user.length>0){
        [_student setValue:user forKey:@"student"];
        if([_student writeToFile:self.filePath atomically:YES]){
            NSLog(@"Student username written properly");
            ChatController *chatController = [[ChatController alloc] initWithUserName:user];
            [self presentViewControllerAsModalWindow:chatController];
        }
        else NSLog(@"Failed to write student useername inside file");
    }
}
@end
